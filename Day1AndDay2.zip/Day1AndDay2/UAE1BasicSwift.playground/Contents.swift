//  Write some awesome Swift code, or import libraries like "Foundation",
//  "Dispatch", or "Glibc"

print("Hello world!")


let maximumNumberOfLoginAttempts: Int

//maximumNumberOfLoginAttempts = 20

var currentLoginAttempt = 0
currentLoginAttempt = 100
print(currentLoginAttempt)

currentLoginAttempt = 200
print(currentLoginAttempt)

var welcomeMessage: String

welcomeMessage = "Maar Haba"
//welcomeMessage = "Good Morning "

//welcomeMessage = 1000

var place = "UAE"
var friendlyMessage = welcomeMessage + place
print(friendlyMessage)

var x = 0.0, y = 0.0, z = 0.0

// String Interpolation in Swift

print("In UAE Most common way to welcome somebody is say, \(friendlyMessage)")

print("X Value is \(x), Y value is \(y) and Z value is \(z)")

var meaningOfLife = 42
//meaningOfLife = 100.10

//Various Numbers Representations Supported in Swift. We have Decimal Numbers, Binary Numbers, Octal and Hexadecimals

let decimalInteger: Int = 17
let binaryInteger: Int = 0b10001
let octalInteger: Int = 0o21
let hexadecimalInteger: Int = 0x11

//let decimalDouble = 12.1875
let decimalDouble = 12.1875
let exponentDouble = 1.21875e1
//let hexadecimalDouble = 0xC.3p0

let oneMillion = 1_000_000

let intMaximumValue = Int64.max
let intMinimumValue = Int64.min

print(intMaximumValue)
print(intMinimumValue)

let intMaxDefaultValue = Int.max
let intMinDefaultValue = Int.min

print(intMaxDefaultValue)
print(intMinDefaultValue)

//
var int8Value: Int8
int8Value = 127
//int8Value = int8Value + 1

let twoThousand: UInt16 = 2_000
let one: UInt8 = 1
//let twoThousandAndOne = UInt8(twoThousand) + one


let three = 3
let pointOneFourOneFiveNine = 0.14159
//let pi = Double(three) + pointOneFourOneFiveNine

let pi = 3.141519
let integerPi = Int(pi)
print(integerPi)

//
typealias AudioSample = UInt16
var macAmplitudeFound = AudioSample.min

let orangesAreOrange: Bool = true
let turnipsAreDelicious = false

if turnipsAreDelicious || orangesAreOrange {
    print("Tasty Turnips!")
} else {
    print("Maaar Haaabbbaa!")
}

let xx = 10

if xx == 10 {
    print("Helloooooo!")
}

/* Following Code is Valid in C/C++/Java/Objective-C But not allowed in Swift because expression(xx) is of Type Int. But Incase expression result to Bool Type and Bool value then it is allowed
 
 if xx {
 print("Not Allowed in Swift")
 } */

let http404Error: (Int, String) = (404, "Not Found")
print(http404Error.0)
print(http404Error.1)

let (theStatusCode, theStatusMessage) = http404Error
print(theStatusCode)
print(theStatusMessage)

// Named Tuple
let http200Error = (statusCode:200, description:"OK")
print(http200Error.statusCode)
print(http200Error.description)

/// Basic Operations
let b = 10
var a = 5
a = b % a
print(a)

let (u, v) = (10, 20)
print(u)
print(v)


var i = 0
// i = i + 1
i += 1
print(i)


let three1 = 3
let minusThree = -three1
let plusThree = -minusThree

/*
 //Comparission Operators
 1 == 1
 2 != 1
 2 > 1
 1 < 2
 1 >= 1
 2 <= 1
 */

print(1 == 1)

if 1 == 1 {
    print("One Is Equal To One")
}

let name = "world"
if name == "world" {
    print("Hello World")
} else {
    print("I am sorry \(name), but I don't recogise you")
}


let contentHeight = 40
let hasHeader = false
let rowHeight = contentHeight + (hasHeader ? 50 : 20)

print(rowHeight)


let currencyAED = false
let dirams = 100
let rupees = 1800


// expression ?  exp1  :  exp2
//is called Ternary Operator

let buyingValue = currencyAED ? dirams : rupees

print(buyingValue)

// a...b is called range operator where a and b are inclusive.
// a..<b is also range operator where a in inclusive but b is excluded.

for index in 1..<5 {
    print("\(index) times 5 is \(index * 5)")
}


// Logical Operators
let allowedEntry = false
if !allowedEntry {
    print("Access Denied")
}

/*
 let enteredDoorCode = true
 let passedRetinaScan = true
 if enteredDoorCode && passedRetinaScan {
 print("Maar Habaaa!")
 } else {
 print("Access Denied")
 }
 
 let hasDoorKey = false
 let knowOverridePassword = true
 if hasDoorKey || knowOverridePassword {
 print("Welcome")
 } else {
 print("Access Denied")
 }
 */

let enteredDoorCode = false
let passedRetinaScan = true
let hasDoorKey = false
let knowOverridePassword = true

if ( enteredDoorCode && passedRetinaScan || hasDoorKey ) && knowOverridePassword {
    print("Maaar Habbaaa!")
} else {
    print("Access Denied")
}


var someString: String? = "Hello, How are you.."
print(someString)
someString = nil

var someNumber: Int? = 10
print(someNumber)

//Uwrapping
print(someNumber!)

someNumber = nil
//print(someNumber!)

if someNumber != nil {
    print(someNumber!)
} else {
    print("someNumber stored Nothing...")
}






