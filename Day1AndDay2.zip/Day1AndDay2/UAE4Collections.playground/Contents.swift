
var someInts: [Int] = [10, 20, 30, 40, 50]
print(someInts)

for value in someInts {
    print(value)
}

//var emptyArrayInt: [Int] = []
var emptyArrayInt = [Int]()
print(emptyArrayInt)

var threeDoubles = [Double](repeating: 2.5, count: 3)
print(threeDoubles)

var anotherThreeDouble = [Double](repeating: 10.0, count:3)
print(anotherThreeDouble)

var sixDoubles = threeDoubles + anotherThreeDouble
print(sixDoubles)

var shoppingList: [String] = []
if shoppingList.isEmpty {
    print("Shopping List is Empty")
} else {
    print("Shopping List has Some Items")
}

shoppingList = ["Eggs", "Milk"]
print(shoppingList)

shoppingList.append("Flour")
print(shoppingList)
shoppingList = shoppingList + ["Baking Powder"]
print(shoppingList)

shoppingList += ["Chocolate Powder", "Cheese", "Butter"]
print(shoppingList)

var firstItem = shoppingList[0]
print(firstItem)
shoppingList[0] = "Six Eggs"
print(shoppingList)

shoppingList[4...6] = ["Bananas", "Apples"]
print(shoppingList)







