// String and Character Data Type in Swift

let someString = "Some string literal value"
//someString = "Abu Dabi"

var anotherEmptyString = ""
/* In JAVA
     String anotherEmptyString = new String();
*/

if anotherEmptyString.isEmpty {
    print("This Another String which is Empty")
}

var emptyInt = Int()
print(emptyInt)

var emptyFloat = Float()
print(emptyFloat)

var emptyDouble = Double()
print(emptyDouble)

var emptyString = String(["A", "B"])
print(emptyString)

/*
if emptyInt == 0 {
    print("Emtp)
}
 */

let exclamationMark: Character = "!"
let catCharacters : [Character] = ["C", "a", "t"]
let catString = String(catCharacters)
print(catString)

// Type Annotation In Swift
// SYNTAX:
//      let|var variableName : DataType = InitialValue

let x : Int = 10, y: Int = 100

let string1 = "Hello"
let string2 = " there"
var welcome = string1 + string2
print(welcome)

var instruction = "look over"
//instruction += string2
instruction = instruction + string2
print(instruction)

welcome.append(exclamationMark)
print(welcome)

let multiplier = 3
let message = "\(multiplier) times 2.5 is \( Double(multiplier) * 2.5 )"
print(message)

let dollarSign = "\u{24}"           // $,  Unicode scalar U+0024
let blackHeart = "\u{2665}"         // ♥,  Unicode scalar U+2665
let sparklingHeart = "\u{1F496}"    // 💖, Unicode scalar U+1F496


// Extended Grapheme Clusters
let eAcute: Character = "\u{E9}"                // é
let combinedEAcute: Character = "\u{65}\u{301}" // e followed by



// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"

// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

if eAcuteQuestion == combinedEAcuteQuestion {
    print("These two strings are considered equal")
}

var word = "cafe"
print("the number of characters in \(word) is \(word.characters.count)")

let greeting = "Maar Habaaa!"
for index in greeting.characters.indices {
    print("\(greeting[index]) ", terminator: "")
}

var welcome2 = "hello"
welcome2.insert("!", at: welcome2.endIndex)


// Prefix and Suffix Equality
var stringArray: [String] = ["USA", "UAE", "India", "China"]
var countryCount = 0
for country in stringArray {
    if country.hasSuffix("a") || country.hasSuffix("A") {
        //countryCount += 1
        countryCount = countryCount + 1
    }
    print("\(country)")
}
print(countryCount)




