var shoppingList: [String] = []
if shoppingList.isEmpty {
    print("Shopping List is Empty")
} else {
    print("Shopping List has Some Items")
}

shoppingList = ["Eggs", "Milk"]
print(shoppingList)

shoppingList.append("Flour")
print(shoppingList)
shoppingList = shoppingList + ["Baking Powder"]
print(shoppingList)

shoppingList += ["Chocolate Powder", "Cheese", "Butter"]
print(shoppingList)

var firstItem = shoppingList[0]
print(firstItem)
shoppingList[0] = "Six Eggs"
print(shoppingList)

shoppingList[4...6] = ["Bananas", "Apples"]
print(shoppingList)

shoppingList.insert("Dates", at: 0)
print(shoppingList)
print(shoppingList.count)

//Stack Simulation
shoppingList.append("Black Dates") // PUSH
print(shoppingList)
shoppingList.append("Super Delicious Dates") //PUSH
print(shoppingList)
shoppingList.removeLast() // POP
print(shoppingList)
shoppingList.removeLast() // POP
print(shoppingList)

//Queue Simulation
shoppingList.insert("Chair", at: 0) // Enqueue
shoppingList.removeLast() // Dequeue
print(shoppingList)
shoppingList.insert("Table", at: 0) // Enqueue
shoppingList.removeLast() // Dequeue
print(shoppingList)

// In Java: foreach
for item in shoppingList {
    print(item)
}

for (index, value) in shoppingList.enumerated() {
    if (index+1) % 2 == 0 {
        print("Item at index \(index+1) is \(value)")
    }
}



// SET
var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip Hop"]
var result = favoriteGenres.contains("Rock")
print(result)

result = favoriteGenres.contains("Sufi Music")
print(result)
favoriteGenres.insert("Arabic Music")
favoriteGenres.insert("Rabbaab")
favoriteGenres.remove("Rock")
print(favoriteGenres)

var setA: Set<Int> = [20, 30, 10]
var setB: Set<Int> = [100, 200, 10]
print(setA.contains(100))
print(setB.contains(100))

var setC = setA.union(setB)
print(setC)
setC = setA.intersection(setB)
print(setC)
setC = setA.symmetricDifference(setB)
print(setC)

// Application of Set
let data: [Int] = [10,  20, -90, 100, 200, 10, 30, 90, 100, -10]
print("Data: \(data)")
var dataSet : Set<Int> = []
for item in data {
    dataSet.insert(item)
}

print("Data After Duplicate Removal Process: \(dataSet)")

if favoriteGenres.isEmpty {
    print("It is Empty Set")
} else {
    print("Set contains \(favoriteGenres.count) Items")
}

print(favoriteGenres)
if let removedGenre = favoriteGenres.remove("Rock") {
    print(removedGenre)
} else {
    print("Item Doesn't Exist")
}

for item in dataSet {
    print(item)
}

print("Sorted Set Output...")
for item in dataSet.sorted().reversed() {
    print(item)
}



