
let finalSquare = 25

var square = 0

while square < finalSquare {
    square  = square + 5
    print("Game Going On!")
}



