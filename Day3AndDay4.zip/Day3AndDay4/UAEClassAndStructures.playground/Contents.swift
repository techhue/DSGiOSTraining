// enum, class and struct
// Used To Create User Defined Data Types
/*
enum TVTechnology {
    case CRT
    case LCD
    case LED
    case PLASMA
}

struct Resolution {
    var width = 0
    var height = 0
}

class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

class TV {
    var videoMode = VideoMode()
    var technology = TVTechnology.LED
}

let someResolution = Resolution()
print(someResolution)
print(someResolution.height)
print(someResolution.width)

let myTVResolution = Resolution(width: 1920, height: 1200)
print(myTVResolution)
print(myTVResolution.height)
print(myTVResolution.width)

let someVideoMode = VideoMode()
print(someVideoMode.resolution)
print(someVideoMode.resolution.width)
print(someVideoMode.resolution.height)
print(someVideoMode.interlaced)
print(someVideoMode.frameRate)
print(someVideoMode.name)

let myTV = TV()
print(myTV.videoMode.resolution)
print(myTV.videoMode.interlaced)
print(myTV.videoMode.frameRate)
print(myTV.videoMode.name)
print(myTV.technology)
*/

//-------------------------
// Object Oriented Programming
// System As Set Of Objects.
//--------------------------

protocol SuperPower {
    func fly ()
}

class Human {
    var power: SuperPower?
    func fly() {
        power!.fly()
    }
}

class Superman: SuperPower {
    func fly() {
        print("Flying Style of Superman")
    }
}

class Spiderman: SuperPower {
    func fly() {
        print("Flying Style of Spiderman")
    }
}

class Aladin: SuperPower {
    func fly() {
        print("Flying Style of Aladin")
    }
}

var amar = Human()
amar.power = Aladin()
amar.fly()







