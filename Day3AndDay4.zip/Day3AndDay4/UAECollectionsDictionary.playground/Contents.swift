
var airports: [String: String] = ["YYZ": "Toronto Pearson", "DXB": "Dubai", "AUD": "Abu Dabi", "SHJ": "Sharaja"]

print(airports["DXB"])
print(airports["SHJ"])

print(airports)
airports["DXB"] = "Dubai Airport"
print(airports)
airports["USA"] = "United State of America"
print(airports)
print(airports["IND"])

if let country = airports["IND"] {
    print(country)
} else {
    print("It is not member")
}

if airports.isEmpty {
    print("No Airport Added")
} else {
    print(airports)
}

if let oldValue = airports.updateValue("Sharaja Airport", forKey:"SHJ") {
    print(oldValue)
} else {
     print("Wrong Key")
}

//let testReturnValue: String? = airports["DUB"]
//print(testReturnValue)

if let airportName = airports["DUB"] {
    print(airportName)
} else {
     print("Wrong Key")
}

if let removedValue = airports.removeValue(forKey: "USA") {
    print(removedValue)
}

for (airportCode, airportName) in airports {
    print("\(airportCode) has name \(airportName)")
}

for key in airports.keys {
    print(key)
}

for value in airports.values {
    print(value)
}

let airportCodes = [String](airports.keys)
let airportNames = [String](airports.values)
print(airportCodes)
print(airportNames)

for code in airportCodes {
    print("Airport Name: \(airports[code]!)")
}


