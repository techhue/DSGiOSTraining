/*
let finalSquare = 25

var square = 0

myLoop: while square < finalSquare {
    square  = square + 5
    switch square {
    case 20:
        print("Game Over!")
        break myLoop
    default:
        print("Game Going On! \(square)")
    }
}

var num = 0
repeat {
    print("World")
    num = num + 1
} while num < 3

if num == 3 {
    print("Three")
} else if num == 5 {
    print("Five")
} else if num == 7 {
    print("Seven")
}

let someCharacter: Character = "\u{089}"
switch someCharacter {
case "a", "e", "i", "o", "u":
    print("It is a English Vowels")
case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
    print("It is English Consonent")
default:
    print("Neither English Vowel and Consonent")
}

let approximateCount = 12
var naturalCount: String
switch approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    //if approximateCount >= 1 && approximateCount < 5 { }
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several"
default:
    naturalCount = "tooo many"
}
print(naturalCount)

*/

let somePoint = (1, 1)
switch somePoint {
case(0, 0):
        print("(0,0) is Origin")
case(let x, 0):
    print("Point Lies of X-Axis with x-coordinate \(x)")
case(0, let y):
    print("Point Lies of Y-Axis with y-coordinate \(y)")
case(-2...2, -2...2):
    print("Point Inside the Box")
//case(_, _):
//    print("Black Hole")
default:
    print("Point Outside Box")
}

let anotherPoint = (1, -1)
switch  anotherPoint {
case let (x, y) where x == y:
    print("Point Lies on Line x == y")
case let (x, y) where x == -y:
    print("Point Lies on Line x == - y")
case let (x, y):
    print("Point(\(x), \(y)) Doesn't Lies on Above Both Lines")
}

let x = 2.2
switch x {
case 1.1:
    print("Value \(x)")
case 2.2:
    print("Value Two \(x)")
case 3.3: // T
    print("Value Three \(x)")
    //break
case 4: // NOT compared
    print("Value In Four \(x)")
    //break
case 3...10: // NOT comapred
    print("Value In Range \(x)")
default:
    print("Value Default \(x)")
}

let integerToDescribe = 5
var description = "The number \(integerToDescribe) is"
switch integerToDescribe {
case 2, 3, 5, 7, 11:
    description += " a prime number, and also"
    fallthrough
default:
    description += " an integer"
}
print(description)

/*
let someArray = [10, 20]
switch someArray {
case [10, 10]:
    print("First")
case [10, 20]:
    print("Second")
default:
    print("Default")
}
*/

let welcome = "Hello"
switch welcome {
case "Hello":
    print("Maar Habaaa!")
case "Hi":
    print("Waah Wah")
default:
    print("Default")
}







