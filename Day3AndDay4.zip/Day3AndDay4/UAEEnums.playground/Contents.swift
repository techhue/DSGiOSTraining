// User Defined Data Types
// Syntax:
//  enum UserDefinedDataTypeName

enum CompassPoint {
    case North
    case South
    case East
    case West
}

var directionToGo: CompassPoint = .West

directionToGo = .East
switch directionToGo {
    case .North:
        print("Lets Go To Ice Code Weather")
    case .South:
        print("See The Sea!")
    case .West:
        print("Make Money and Grow!")
    case .East:
        print("Land of Many Gods!")
}

enum Planet: Int {
    case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Neptune, Pluto
}

let somePlanet: Planet = Planet.Earth
switch somePlanet {
case .Earth:
    print("Life Exists Here")
default:
    print("There Is No Sign of Life Existance Here")
}

var enumValue: Planet = Planet.Earth
var rawValue: Int = Planet.Earth.rawValue

print(Planet.Earth)
print(Planet.Earth.rawValue)





