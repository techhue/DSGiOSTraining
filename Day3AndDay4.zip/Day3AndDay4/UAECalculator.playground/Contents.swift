/*
func sum(a: Int, b: Int) -> Int {
    return a + b
}

func sub(a: Int, b: Int) -> Int {
    return a - b
}

func mul(a: Int, b: Int) -> Int {
    return a * b
}

func div(a: Int, b: Int) -> Int {
    return a / b
}

func calculator(num1: Int, num2: Int, operation: (Int, Int) -> Int ) -> Int
{
    var result: Int
    result = operation(num1, num2)
    return result
}

calculator(num1: 20, num2: 10, operation: sub)
let something: (Int, Int) -> Int = sum
print( something( 100, 200) )

///-------------------------
func iFly(flying: ()->() ) {
    flying()
}

func spiderManFly() {
    print("Flying Like Spiderman")
}

func superManFly() {
    print("Flying Like Superman")
}

func aladinFly() {
    print("Flying Like Aladin")
}

func heManfly() {
    print("Flying Like Heman")
}

//Polymorphism
iFly(flying: heManfly)

//-------------------------------------

func stepForward(input: Int) -> Int {
    return input + 2
}

func stepBackward(input: Int) -> Int {
    return input - 3
}

func chooseStepFunction(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}


var currentValue = 3
let moveNearerToZero = chooseStepFunction(backwards: currentValue > 0 )
print("Counting Towards Zero...")
while currentValue != 0 {
    print(currentValue)
    currentValue = moveNearerToZero(currentValue)
}
print("We Reached ZERO!")

//----------------------------

func cookChicken() {
    print("Proccess of Cooking Chicken")
}

func cookMutton() {
    print("Proccess of Cooking Mutton")
}

func cookSoup() {
    print("Proccess of Cooking Soup")
}

func Owner(choice: String) -> ()->() {
    var cook: ()->()
    switch choice {
        case "Chicken":
            cook = cookChicken
        case "Mutton":
            cook = cookMutton
        default:
            cook = cookSoup
    }
    return cook
}

func servent1(cook:()->()) {
    cook()
}

func servent2(cook:()->()) {
    cook()
}

let todayMenu = Owner(choice: "Chicken")
servent2(cook:todayMenu)
*/
//---------------------------------------------
let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]


func forwards(s1: String, s2: String) -> Bool {
    return s1 < s2
}

func backwards(s1: String, s2: String) -> Bool {
    return s1 > s2
}

// Invariant Functions
var sortedNames = names.sorted(by: backwards)
print(sortedNames)
sortedNames = names.sorted(by: forwards)
print(sortedNames)

//Closure Syntax
//---------------------------------------------


var sortedNamesWithClosure = names.sorted(by: { (s1: String, s2: String) -> Bool in return s1 > s2 } )
print("Closure: \(sortedNamesWithClosure)")

var sortedNamesWithClosure1 = names.sorted(by: { (s1, s2) in return s1 > s2 } )
print("Closure1: \(sortedNamesWithClosure1)")

var sortedNamesWithClosure2 = names.sorted(by: { (s1, s2) in  s1 > s2 } )
print("Closure2: \(sortedNamesWithClosure2)")

var sortedNamesWithClosure3 = names.sorted(by: {  $0 > $1 } )
print("Closure3: \(sortedNamesWithClosure3)")

var sortedNamesWithClosure4 = names.sorted(by: < )
print("Closure4: \(sortedNamesWithClosure4)")

