//---------------------------------------------
// Object Oriented Programming
// System As Set Of Objects.
//---------------------------------------------

protocol SuperPower {
    func fly ()
    func saveWorld()
}

class Human {
    var power: SuperPower?
    func fly() {
        power!.fly()
    }
    func saveWorld() {
        power!.saveWorld()
    }
}

class Superman: SuperPower {
    func fly() {
        print("Flying Style of Superman")
    }
    func saveWorld() {
        print("Superman Saved The World!")
    }
}

class Spiderman: SuperPower {
    func fly() {
        print("Flying Style of Spiderman")
    }
    func saveWorld() {
        print("Spiderman Saved The World!")
    }
}

class Aladin: SuperPower {
    func fly() {
        print("Flying Style of Aladin")
    }
    func saveWorld() {
        print("Aladin Saved The World!")
    }
}

//I. Programming in C By Kernigham and Denish Ritchie.
//II. Programming in C, Schaum Series, By Gottfred.
//Chapters To Study
// 1. Array Chapter
// 2. Pointer Chapter
// 3. Function Chapter

//---------------------------
//Create Objects
//Settings The Relationships
var amar = Human()
amar.power = Spiderman()
//Sending Message To Amar
amar.fly()
amar.saveWorld()

amar.power = Aladin()
amar.fly()
amar.saveWorld()






