// enum, class and struct
// Used To Create User Defined Data Types

enum TVTechnology {
    case CRT
    case LCD
    case LED
    case PLASMA
}

struct Resolution {
    var width = 0
    var height = 0
}

class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

class TV {
    var videoMode = VideoMode()
    var technology = TVTechnology.LED
}

// In Java
// Resolution someResolution = new Resolution();
/*
let someResolution = Resolution()
print(someResolution)
print(someResolution.height)
print(someResolution.width)

let myTVResolution = Resolution(width: 1920, height: 1200)
print(myTVResolution)
print(myTVResolution.height)
print(myTVResolution.width)

let someVideoMode = VideoMode()
print(someVideoMode.resolution)
print(someVideoMode.resolution.width)
print(someVideoMode.resolution.height)
print(someVideoMode.interlaced)
print(someVideoMode.frameRate)
print(someVideoMode.name)

let myTV = TV()
print(myTV.videoMode.resolution)
print(myTV.videoMode.interlaced)
print(myTV.videoMode.frameRate)
print(myTV.videoMode.name)
print(myTV.technology)
//-------------------------------

var l = [10, 20, 30, 40, 50]
var m = l
m[0] = 100
print(l)
print(m)
 */

let hd = Resolution(width: 1920, height: 1080)
var cinema = hd // Value Copy
cinema.width = 2048
print(hd)
print(cinema)


let tenEighty = VideoMode()
tenEighty.resolution = hd // Value Copy
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty // Reference Copy
print(tenEighty.frameRate)
print(alsoTenEighty.frameRate)

alsoTenEighty.frameRate = 30.0
print(tenEighty.frameRate)
print(alsoTenEighty.frameRate)

if tenEighty === alsoTenEighty {
    print("Both are referring to same Object")
} else {
    print("Both are referring to Different Object")
}


//--------------------------------------------
var l = [10, 20, 30]
var m = [100, 200]
var n = [l, m]
l[0] = 1000
print(l)
print(n)
var nn = n

print(n[0])
print(n[0][0])
n[0][0] = 2000
print(n)
print(nn)

//Musbah/Chiraag - Lamp
//



