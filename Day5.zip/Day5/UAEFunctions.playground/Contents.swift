/*
func sayHelloWorld() -> String {
    return "Hello World"
}
print(sayHelloWorld())

func printHello() {
    print("Helloooooooo!")
}
printHello()

func sayHelloAgain(personName: String) -> String {
    return "Hello My Dear! \(personName)"
}

let retunedString = sayHelloAgain(personName: "Baseeem")
//print(retunedString)
//print(sayHelloAgain(personName: "Baseeem"))

func sum(number1: Int, number2: Int) -> Int {
    var result = 0
    result = number1 + number2
    return result
}
*/

func minMax( array: [Int] ) ->  (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

let bounds = minMax(array: [10, 20, -100, 100, 200, 90, 70, 55])
print("Minimum Value: \(bounds.min) \nMaximum Value: \(bounds.max)")

func join( s1: String, s2: String, joiner: String) -> String {
        return s1 + joiner + s2
}
print( join( s1: "Hello", s2: "World!", joiner: "#"))

// Function's External(Society Name) and Internal(Pet Name) Parameters
// Default Parameters
func join(string s1: String, toString s2: String, withJoiner joiner: String = "        ") -> String {
    return s1 + joiner + s2
}
print( join( string: "Hello", toString : "World!", withJoiner: "---"))
print( join( string: "Hello", toString : "World!"))

//Function with Variable Number of Parameters
func arithmeticMean(numbers: Double...) -> Double {
    var total: Double = 0.0
    for number in numbers {
        total += number
    }
    return total / Double(numbers.count)
}
arithmeticMean(numbers: 1, 2, 3, 4, 5)
arithmeticMean(numbers: 3, 8, 19)
arithmeticMean(numbers: 10, 20, 30, 40, 50, 60, 70, 80, 90)

//let|var a : Int
func swap(a: inout Int, b: inout Int) {
    let temp = a
    a = b
    b = temp
}
var someInt = 3
var anotherInt = 107
swap(a: &someInt, b: &anotherInt)
print(someInt, anotherInt)

var a = 10

func doChange(a: inout Int) {
    a = 1000
    print("Inside Function value of a: \(a)")
}

print("Outside Function value of a: \(a)")
doChange(a: &a)
print("Outside Function value of a: \(a)")


//_______________________________________










