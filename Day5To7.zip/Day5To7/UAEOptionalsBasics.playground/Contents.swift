//: ## Optionals
let possibleNumber = "123"
let convertedNumber: Int? = Int(possibleNumber)
// convertedNumber is inferred to be ot type "Int?" (optional Int)

if convertedNumber != nil {
    let actualNumber = convertedNumber!
    print("\(possibleNumber) has an integer value of \(actualNumber)")
} else {
    print("\(possibleNumber) could not be converted to an integer")
    print("Converted Number is \(convertedNumber)")
}

//idioms and phrases in a language. Set of words which makes sentence far more meaningful. We call it proverbs also.

/*
 Following Code Is Doing These Steps
     Step 1. Converting possibleNumber Type to Int?
     Step 2. Coverting possibleNumber to Value of Type Int?
     Step 3. Optional Return of Step 2 is checked for != nil
     Step 4. Unwrap Optional Value
     Step 5. Bind Unwrapped Value Stored in Optional to actualNumber
                 Here actualNumber is of Type Int.
 */

// CODE BLOCK 1. STARTS
if var actualNumber = Int(possibleNumber) {
    print("\(possibleNumber) has integer value of \(actualNumber)")
    // NOTE: actualNumber is local to this block
    actualNumber = actualNumber + 100
} else {
    print("\(possibleNumber) could not be converted to an integer")
    //print("Trying To Access: \(actualNumber)")
    // NOTE: As actualNumber is local to above block
    //       You cann't access it here.
}
// CODE BLOCK 1. ENDS

// Compiler will Generate Following Code For CODE BLOCK1
let temporaryVariable = Int(possibleNumber)
if temporaryVariable != nil {
    let actualNumber = temporaryVariable!
    print("\(possibleNumber) has integer value of \(actualNumber)")
} else {
    print("\(possibleNumber) could not be converted to an integer")
    //print("Trying To Access: \(actualNumber)")
}

/* In Java Lanaguage: Null Exception
     String dingDong = null;
     printf("Value at dingDong: %s", dingDong);

     let dingDong: String? = nil
     if dingDong != nil {
         print(dingDong!)
     }
 */


// CODE BLOCK 2. STARTS
if let firstNumber = Int("42"), let secondNumber = Int("100"), firstNumber < secondNumber {
    print("\(firstNumber) is less than \(secondNumber)")
}
// CODE BLOCK 2. ENDS

// Compiler Will Generate Following Code For CODE BLOCK 2
let temporaryFirst: Int? = Int("42")
let temporarySecond: Int? = Int("100")
if temporaryFirst != nil && temporarySecond != nil {
    let firstNumber = temporaryFirst!
    let secondNumber = temporarySecond!
    if firstNumber < secondNumber {
        print("\(firstNumber) is less than \(secondNumber)")
    }
}

// CODE BLOCK 3. STARTS
let a: Int? = 4
let b: Int? = 10
let c: Int? = nil
if let A = a, let B = b, let C = c {
    print(A, B, C)
} else {
    print("Atleast One Of The Optional is nil. Hence None is Unwrapped")
}
// CODE BLOCK 3. ENDS

// Compiler Will Generate Following Code For CODE BLOCK 3
if a != nil && b != nil && c != nil {
    let tempA = a!
    let tempB = b!
    let tempC = c!
    print(tempA, tempB, tempC)
} else {
    print("Atleast One Of The Optional is nil. Hence None is Unwrapped")
}

// FOLLOWING IS BAD PROGRAMMING PRACTICE
let possibleString: String? = "An optional string."
//In Following Line We are Doing Forced Unwrapping: It is UNSAFE
let forcedString: String = possibleString!

let assumedString: String! = "An Implicity Unwrapped Optional String"




