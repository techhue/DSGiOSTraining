class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}
class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}
class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}

let library = [
    Movie(name: "Casablanca", director: "Michael Curtiz"),
    Song(name: "Blue Suede Shoes", artist: "ElvisPresley"),
    Movie(name: "Citizen Kane", director: "Orson Welles"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley")]

var movieCount = 0
var songCount  = 0
for item in library {
    if item is Movie {
        movieCount = movieCount + 1
    } else if item is Song {
        songCount = songCount + 1
    }
}

for item in library {
    if let movie = item as? Movie {
        print("Movie: \(movie.name), Director: \(movie.director)")
    } else if let song = item as? Song {
        print("Song: \(song.name), Director: \(song.artist)")
    }
}

var things: [Any] = [100, "Hello", Movie(name: "Casablanca", director: "Michael Curtiz"),
                     Song(name: "Blue Suede Shoes", artist: "ElvisPresley") ]

for thing in things {
    switch thing {
    case 100 as Int:
        print("It is Int Type")
    case "Hello" as String:
        print("It is String Type")
    case let movie as Movie:
        print("It is Movie Type \(movie)")
    case let song as Song:
        print("It is Song Type \(song)")
    default:
        print("No Matching Type")
    }
}



