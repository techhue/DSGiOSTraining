class Counter {
    var count = 0
    func increment() {
        count += 1
    }
    func incrementBy(amount: Int) {
        count += amount
    }
    func reset() {
        count = 0
    }
}

let counter: Counter = Counter()
counter.increment()
counter.incrementBy(amount: 10)
print(counter.count)

let counter1: Counter = Counter()
counter1.incrementBy(amount: 20)
print(counter1.count)


//The self Property
// struct and enum properties are immuatble by default
// Mutating function should be prefixed with mutating keyword

struct Point {
    var x = 0.0, y = 0.0
    func isRightOfX(x: Double) -> Bool {
        return self.x > x
    }
    func yCoordiante(y: Double) {
        print("Y Coordiante Is: \(y)")
        print("Y Coordiante Is: \(self.y)")
    }
    mutating func changePoint(XChangeBy: Double, YChangeBy: Double) {
        x = x + XChangeBy
        y = y + YChangeBy
    }
}

var somePoint = Point(x: 4.0, y: 5.0)
if somePoint.isRightOfX(x: 6.0) {
    print("\(somePoint) Right of X")
} else {
    print("\(somePoint) Left of X")
}

somePoint.yCoordiante(y:10.9)
somePoint.changePoint(XChangeBy: 5.0, YChangeBy: 10.0)
print(somePoint)

//-----------------------

enum Gear {
    case Neutral, First, Second, Third, Fourth
    mutating func next() {
        switch self {
            case .Neutral:
                self = .First
            case .First:
                self = .Second
            case .Second:
                self = .Third
            case .Third:
                self = .Fourth
            case .Fourth:
                self = .Fourth
        }
    }
}

var gear: Gear = Gear.First
print(gear)
gear.next()
print(gear)
gear.next()
print(gear)

//---------------------------



