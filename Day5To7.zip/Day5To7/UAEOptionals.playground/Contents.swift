//Optional Chaining
/*
class Person {
    var residence: Residence?
}
class Residence {
    var numberOfRooms = 1
}

var john = Person()
john.residence = Residence()
//print(john.residence?.numberOfRooms)
if let roomCount = john.residence?.numberOfRooms {
    print("Room Count \(roomCount)")
} else {
    print("Unable To Retreive The Rooms")
}
*/

class Person {
    var residence: Residence?
}
class Residence {
    var rooms = [Room]()
    var address: Address?
    var numberOfRooms: Int {
        return rooms.count
    }
    subscript(i: Int) -> Room {
        return rooms[i]
    }
    func printNumberOfRooms() {
        print("The Number of Rooms is \(numberOfRooms)")
    }
}
class Room {
    let name: String
    init(name: String) { self.name = name }
}
class Address {
    var buildingName: String?
    var buildingNumber: String?
    var street: String?
    func buildingIdentifier() -> String? {
        if buildingName != nil {
            return buildingName
        } else if buildingNumber != nil {
            return buildingNumber
        } else {
            return nil
        }
    }
}

let john = Person()
if let roomCount = john.residence?.numberOfRooms {
    print("Room Count \(roomCount)")
} else {
    print("Unable To Retreive The Rooms")
}

if john.residence?.printNumberOfRooms() != nil {
    print("Able To Print Rooms")
} else {
    print("NOT Able To Print Rooms")
}

if let firstRoomName = john.residence?[0].name {
    print("Room Name \(firstRoomName)")
} else {
    print("Unable To Retrieve Room Name")
}

let johnHouse = Residence()
johnHouse.rooms += [Room(name: "Living Room")]
johnHouse.rooms += [Room(name: "Kitchen")]
john.residence = johnHouse

if let firstRoomName = john.residence?[0].name {
    print("Room Name \(firstRoomName)")
} else {
    print("Unable To Retrieve Room Name")
}

if let johnStreet = john.residence?.address?.street {
    print("Street name \(johnStreet)")
} else {
    print("Unable to retrieve the address")
}

let johnAddress = Address()
johnAddress.buildingNumber = "1000"
johnAddress.buildingName   = "Emaar Building"
johnAddress.street         = "Dubai Mall Street"
john.residence!.address    = johnAddress

if let johnStreet = john.residence?.address?.street {
    print("Street name \(johnStreet)")
} else {
    print("Unable to retrieve the address")
}

if let buildingId = john.residence?.address?.buildingIdentifier()?.hasPrefix("The") {
    print(buildingId)
}



