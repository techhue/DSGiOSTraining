class PedalSystem {
    var pressedValue: Int = 10
    func pressPedal(pedal: String) -> Int {
        return pressedValue
    }
}

class Engine {
    var name: String = "Toyota"
    var speed: Int = 5
    func startEngine() {
        print("Engine Started")
    }
    func runEngine(gear: Int, pedal: Int) -> Int {
        print("Running Engine in Gear \(gear) and Drive Speed Pedal \(pedal)")
        return speed
    }
}

class GearBox {
    var gearSelected: Int = 1
    func changeGear(move: String) -> Int {
        switch move {
        case "First":
                gearSelected = 1
        case "Second":
                gearSelected = 2
        default:
                gearSelected = 3
        }
        return gearSelected
    }
}

class TyreSystem {
    func moveTyres(speed: Int) {
        print("Move Tyres with Speed: \(speed)")
    }
}

var engine = Engine()
var gearBox = GearBox()
var tyreSystem = TyreSystem()
var pedalSystem = PedalSystem()
//Manufacturer Of Car Given You


//Driving and Using Car
/*
engine.startEngine()
var gearValue = gearBox.changeGear(move: "First")
var pedalValue = pedalSystem.pressPedal(pedal: "Drive")
var speedValue = engine.runEngine(gear: gearValue, pedal: pedalValue)
tyreSystem.moveTyres(speed: speedValue)/
*/

/*
var car = Car()
car.startCar()
car.moveCar()
car.changeGear()
car.stopCar()
*/



