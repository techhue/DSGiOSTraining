struct IntStack {
    var items: [Int] = []
    mutating func push(item: Int) {
            items.append(item)
    }
    
    mutating func pop() -> Int {
        return items.removeLast()
    }
}

struct StringStack {
    var items: [String] = []
    mutating func push(item: String) {
        items.append(item)
    }
    
    mutating func pop() -> String {
        return items.removeLast()
    }
}

var stack = IntStack()
stack.push(item: 10)
stack.push(item: 20)
stack.push(item: 100)
print(stack.items)
stack.pop()
print(stack.items)

var stackS = StringStack()
stackS.push(item: "Ding")
stackS.push(item: "Dong")
stackS.push(item: "King")
stackS.push(item: "Kong")
print(stackS.items)
stackS.pop()
print(stackS.items)

//Generics

struct Stack<T> {
    var items = [T]()
    mutating func push(item: T) {
        items.append(item)
    }
    
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var stackStrings = Stack<String>()
stackStrings.push(item: "DDing")
stackStrings.push(item: "DDong")
stackStrings.push(item: "KKing")
stackStrings.push(item: "KKong")
print(stackStrings.items)
stackStrings.pop()
print(stackStrings.items)

var stackI = Stack<Int>()
stackI.push(item: 100)
stackI.push(item: 200)
stackI.push(item: 1000)
print(stackI.items)
stackI.pop()
print(stackI.items)

var stackD = Stack<Double>()
stackD.push(item: 100.00)
stackD.push(item: 200.01)
stackD.push(item: 1000.01)
print(stackD.items)
stackD.pop()
print(stackD.items)
/*
struct Queue<(T, T)> {
    var items = [(T]
    mutating func push(item: T) {
        items.append(item)
    }
    
    mutating func pop() -> T {
        return items.removeLast()
    }
}
*/



