/*
 var reference1: Person?
 var reference2: Person?
 var reference3: Person?
 
 reference1 = Person(name: "Dubai")
 reference2 = reference1
 reference3 = reference1
 
 reference1 = nil
 reference2 = nil
 reference3 = nil
 */

class Person {
    let name: String
    var apartment: Apartment?
    init(name: String) { self.name = name ; print("Person.Init") }
    deinit { print("Person: Deinitialzed")  }
}

class Apartment {
    let number: Int
    weak var tenant: Person?
    init(number: Int)  { self.number = number; print("Apartment.Init") }
    deinit {  print("Apartment: Deinitialzed")  }
}

var ahmad: Person?
var emmar: Apartment?

/*
ahmad = Person(name: "Ahmad Mustfa")
emmar = Apartment(number: 2107)
ahmad?.apartment = emmar
emmar?.tenant = ahmad
ahmad = nil
emmar = nil
*/

//--------------------------------

class World {
    let name: String
    let text: String?
    init(name: String, text: String? = nil) {
        self.name = name
        self.text = text
        print("World: Initialzed")
    }
    lazy var hello: () -> String = {
        [unowned self] in
        if let text = self.text {
            return "Hello! \(self.name). \(text)"
        }
        return "Hello! \(self.name). \(self.text)"
    }
    deinit {  print("World: Deinitialzed")  }
}

var world: World? = World(name: "John", text: " How are you?")
print(world?.hello())
world = nil

//-----------------------------

