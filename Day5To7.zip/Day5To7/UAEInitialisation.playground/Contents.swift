class Celsius {
    var temperatureInCelsius: Double = 0.0
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }
    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
    init(celsius: Double) {
        temperatureInCelsius = celsius
    }
    deinit {
        print("Deinit Is Called")
    }
}

var bodyTemp: Celsius? = Celsius(celsius: 37.0)
print(bodyTemp!.temperatureInCelsius)
bodyTemp = nil

