let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits

let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8  = 0b00111111

let result = firstSixBits | lastSixBits

let shiftBits: UInt8 = 4
shiftBits >> 1
shiftBits >> 2

//Operator Functions / Operator Overloading

struct Point {
    var x = 0.0, y = 0.0
}

func == (firstPoint: Point, secondPoint: Point ) -> Bool {
    return (firstPoint.x == secondPoint.x) && (firstPoint.y == secondPoint.y)
}

var point1 = Point(x:3.0, y:4.0)
var point2 = Point(x:3.0, y:4.0)
var point3 = Point(x:4.0, y:4.0)

if point1 == point3 {
    print("Both Points are Equal")
} else {
    print("Both Points are UNEqual")
}


