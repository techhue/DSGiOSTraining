// Computed Properties
struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var width = 0.0, height = 0.0
}
struct Rectangle {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set(newCenter) {
            origin.x = newCenter.x - (size.width / 2)
            origin.y = newCenter.y - (size.height / 2)
        }
    }
    
    //Computed Read Only Property
    var area: Double {
            return size.width * size.height
    }
}

/*
var rect = Rectangle()
//print(rect.origin)
//print(rect.size)

print(rect.center)
//print(rect.center.get())

rect.center = Point(x: 10, y: 10)
//rect.center.set( Point(x:10, y:10) )

print(rect.center)

rect.size = Size(width: 20, height: 30)
print(rect.area)
// print(rect.area.get())
//rect.area = 800

struct SomeStructure {
    static var storedTypeProperty = "Some Structure Value"
    static var computedTypeProperty: Int {
        return 10
    }
}

//var somestruct = SomeStructure()
print(SomeStructure.storedTypeProperty)
print(SomeStructure.computedTypeProperty)

enum SomeEnumeration {
    static var storedTypeProperty = "Some Enum Value"
    static var computedTypeProperty: Int {
        return 20
    }
}

//var someenum = SomeEnumeration()
print(SomeEnumeration.storedTypeProperty)
print(SomeEnumeration.computedTypeProperty)

class SomeClass {
    static var storedTypeProperty = "Some Class Value"
    static var computedTypeProperty: Int {
        return 30
    }
    
    //class var classStoredTypeProperty = "Some Class Value"
    class var overiableComputedTypeProperty: Int {
        return 30
    }
}

var someclass = SomeClass()
print(SomeClass.storedTypeProperty)
print(SomeClass.computedTypeProperty)
print(SomeClass.overiableComputedTypeProperty)
*/
// Usages of Type Properties

struct AudioPlayer {
    static var maximumAudioLevel = 10
    var currentLevel: Int = 0 {
        didSet {
            if currentLevel > AudioPlayer.maximumAudioLevel {
                currentLevel = AudioPlayer.maximumAudioLevel
            }
        }
    }
}

var baseemAudioPlayer = AudioPlayer()
var saumyaAudioPlayer = AudioPlayer()
var amarAudioPlayer   = AudioPlayer()

baseemAudioPlayer.currentLevel = 5
saumyaAudioPlayer.currentLevel = 8
amarAudioPlayer.currentLevel = 3

print("Baseem Audio Level: \(baseemAudioPlayer.currentLevel)")
print("Saumya Audio Level: \(saumyaAudioPlayer.currentLevel)")
print("Amar Audio Level: \(amarAudioPlayer.currentLevel)")

baseemAudioPlayer.currentLevel = 11
saumyaAudioPlayer.currentLevel = 15
amarAudioPlayer.currentLevel   = 20

print("Baseem Audio Level: \(baseemAudioPlayer.currentLevel)")
print("Saumya Audio Level: \(saumyaAudioPlayer.currentLevel)")
print("Amar Audio Level: \(amarAudioPlayer.currentLevel)")

print(AudioPlayer.maximumAudioLevel)

class Cook {
    static var breadCount = 0
    func makeBread(breads: Int) {
        Cook.breadCount = Cook.breadCount + breads
        print("Made Breads: \(breads)")
    }
}

var cook1 = Cook()
var cook2 = Cook()
var cook3 = Cook()

cook1.makeBread(breads: 10)
cook2.makeBread(breads: 20)
cook3.makeBread(breads: 25)
cook1.makeBread(breads: 15)
//cook2 on break
cook3.makeBread(breads: 25)
print(Cook.breadCount)

