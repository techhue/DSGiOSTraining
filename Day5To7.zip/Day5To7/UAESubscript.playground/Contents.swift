
struct Table {
    var multiplier: Int = 2
    subscript(index: Int) -> Int {
        return multiplier * index
    }
}

let threeTable = Table(multiplier: 3)
print(threeTable[1])
print(threeTable[2])
print(threeTable[3])
print(threeTable[4])
print(threeTable[5])

struct Number {
    var value: Int = 0
    subscript(digitIndex: Int) -> Int {
        var digitIndex = digitIndex
        var decimalBase = 1
        while digitIndex > 0 {
                decimalBase *= 10
                digitIndex -= 1
        }
        return ( value / decimalBase ) % 10
    }
/*
    func getDigit(index: Int) -> Int {
        
    }
 */
}

var num = Number(value: 128976)
print(num.value)
print(num[0])
print(num[1])
print(num[2])
print(num[3])






