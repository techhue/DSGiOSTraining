protocol SuperPower {
    func fly()
    func saveWorld()
}

class Human {
    var power: SuperPower?
    func fly() {
        power!.fly()
    }
    func saveWorld() {
        power!.saveWorld()
    }
}

class SuperMan : SuperPower {
    func fly() {
        print("Superman Flying!")
    }
    func saveWorld() {
        print("Superman Saved World!")
    }
}

class SpiderMan : SuperPower {
    func fly() {
        print("Spiderman Flying!")
    }
    func saveWorld() {
        print("Spiderman Saved World!")
    }
}

class Aladin: SuperPower {
    func fly() {
        print("Aladin Flying!")
    }
    func saveWorld() {
        print("Aladin Saved World!")
    }
}

class HeMan : SuperPower {
    func fly() {
        print("HeMan Flying!")
    }
    func saveWorld() {
        print("HeMan Saved World!")
    }
}

func + (human: Human, superpower: SuperPower) {
    human.power = superpower
}

func - (human: Human, superpower: SuperPower) {
    human.power = nil
}

/*
var human = Human()
var aladin = Aladin()
human.power = aladin
human.fly()
human.saveWorld()
*/

var human = Human()
var aladin = Aladin()
var superman = SuperMan()
human + aladin
human - aladin
human + superman
//human.+(aladin)

10 + 20

var heman = HeMan()
/*
heman.fly()
heman.saveWorld()
*/
human - superman
human + heman
human.fly()
human.saveWorld()




