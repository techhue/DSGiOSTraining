class Vehicle {
    var numberOfWheels: Int
    var maxPassengers: Int
    init() {  // Default Initializer
        numberOfWheels =  4
        maxPassengers  = 30
    }
    init(wheels: Int, maxPassengers: Int) {
        self.numberOfWheels =  wheels
        self.maxPassengers  =  maxPassengers
    }
    func description() -> String {
        return "Parent Class: Vehicle"
//        \(numberOfWheels) Wheels and \(maxPassengers) Maximum Passenger"
    }
}
class Bicycle : Vehicle {
    override init() {  // Default Initializer
        super.init()
        numberOfWheels = 2
        maxPassengers  = 2
    }
    override init(wheels: Int, maxPassengers: Int) {
        super.init(wheels: wheels, maxPassengers: maxPassengers)
        self.numberOfWheels =  wheels
        self.maxPassengers  =  maxPassengers
    }
    
    override func description() -> String {
        print(super.description())
        return "Child Class: Bicycle"
    }
}

class Tricycle : Bicycle {
    override init() {
        super.init()
        numberOfWheels = 3
        maxPassengers  = 4
    }
}

class Car: Vehicle {
    var speed: Double = 0.0
    override init() {
        super.init()
        maxPassengers   = 5
        numberOfWheels  = 4
    }
    
    override func description() -> String {
        return super.description() + " Travelling Speed: \(speed)"
    }
}

class AutomaticCar: Car {
    var gear = 1
    override func description() -> String {
        return super.description() + " In Gear: \(gear)"
    }
}

/*
let someVehicle = Vehicle()
print(someVehicle.numberOfWheels)
print(someVehicle.maxPassengers)
print(someVehicle.description())

let someBicycle1 = Bicycle()
print(someBicycle1.numberOfWheels)
print(someBicycle1.maxPassengers)
print(someBicycle1.description())

let someBicycle2 = Bicycle(wheels: 2, maxPassengers: 2)
print(someBicycle2.numberOfWheels)
print(someBicycle2.maxPassengers)
print(someBicycle2.description())
*/

let triCycle = Tricycle()
print(triCycle.numberOfWheels)
print(triCycle.maxPassengers)
print(triCycle.description())

let car = Car()
print(car.numberOfWheels)
print(car.maxPassengers)
print(car.description())

let autoCar = AutomaticCar()
print(autoCar.numberOfWheels)
print(autoCar.maxPassengers)
print(autoCar.description())




