
class Engine {
    var moveValue: Int = 0
    func startEngine(gear: Int, peddle: (breakValue: Int, raceValue: Int)) -> Int
    {
        print("Engine Started: Gear: \(gear), Break: \(peddle.breakValue), Race: \(peddle.raceValue)")
        return calculateMove(gear: gear, peddle: peddle)
    }
    
    func runEngine(gear: Int, peddle: (breakValue: Int, raceValue: Int)) -> Int {
        print("Engine Running: Gear: \(gear), Break: \(peddle.breakValue), Race: \(peddle.raceValue)")
        return calculateMove(gear: gear, peddle: peddle)
    }
    
    func stopEngine(gear: Int, peddle:  (breakValue: Int, raceValue: Int)) -> Int
    {
        print("Engine Stopped: Gear: \(gear), Break: \(peddle.breakValue), Race: \(peddle.raceValue)")
        return calculateMove(gear: gear, peddle: peddle)
    }
    
    func calculateMove(gear: Int, peddle: (breakValue: Int, raceValue: Int)) -> Int {
        if peddle.breakValue == 10 {
            moveValue = 0
        } else {
            // moveValue should be Calculated Based on gearValue and raceValue
            // We are here calculating it only based on raceValue
            switch peddle.raceValue {
            case 1...30:
                moveValue = 30
            case 31...60:
                moveValue = 60
            case 61...100:
                moveValue = 100
            default:
                moveValue = 0
            }
        }
        return moveValue
    }
}

class GearBox {
    var gear: Int = 0
    func changeGear(selectGear: String) -> Int {
        switch selectGear {
        case "First":
            gear = 1
        case "Second":
            gear = 2
        case "Third":
            gear = 3
        case "Fourth":
            gear = 4
        default:
            gear = 0
        }
        return gear
    }
}

class PeddleSystem {
    var breakValue = 0  // 0 to 10
    var raceValue  = 0  // 0 to 100
    func peddlePressed(breakPressed: Int, racePressed: Int) -> (breakValue: Int, raceValue: Int) {
        
        if breakPressed >= 0 && breakPressed <= 10 {
            breakValue = breakPressed
        } else if breakPressed < 0 {
            breakValue = 0
        } else if breakPressed > 10 {
            breakValue = 10
        }

        raceValue = racePressed
        return (breakValue, raceValue)
    }
}

class TyreSystem {
    func moveTyres(moveValue: Int) {
        print("Typres Moved: \(moveValue)")
    }
    func direction(direction: Int) {
        //Implement It
    }
}

class SteeringSystem {
    //Implement It
    func steer(steerValue : Int ) {
        
    }
}
class Car {
    var engine = Engine()
    var gearBox = GearBox()
    var peddleSystem = PeddleSystem()
    var tyreSytem = TyreSystem()
    
    var gearValue = 0
    var peddleValue: (Int, Int) = (0, 0)
    var moveValue = 0
    
    func changeGear(selectGear: String) {
        gearValue = gearBox.changeGear(selectGear: selectGear)
    }
    
    func start() {
        peddleValue  = peddleSystem.peddlePressed(breakPressed: 0, racePressed: 10)
        moveValue = engine.startEngine(gear: gearValue, peddle: peddleValue)
        //tyreSystem.direction()
        tyreSytem.moveTyres(moveValue: moveValue)
    }
    
    func run() {
        peddleValue  = peddleSystem.peddlePressed(breakPressed: 0, racePressed: 100)
        moveValue = engine.runEngine(gear: gearValue, peddle: peddleValue)
        //tyreSystem.direction()
        tyreSytem.moveTyres(moveValue: moveValue)
        
    }
    
    func stop() {
        peddleValue  = peddleSystem.peddlePressed(breakPressed: 10, racePressed: 1)
        moveValue = engine.stopEngine(gear: gearValue, peddle: peddleValue)
        //tyreSystem.direction()
        tyreSytem.moveTyres(moveValue: moveValue)
    }
}

// Engine engine = new Engine();
var car = Car()
car.start()
car.changeGear(selectGear: "First")
car.run()
car.changeGear(selectGear: "Netural")
car.stop()
//car.steer(steer: Int)



