// Stored Properties
/*
struct Resolution {
    var width = 0  // Stored Properties
    var height = 0
}

var r1 = Resolution(width: 100, height: 200)
var r2 = Resolution(width: 300, height: 300)
print(r1)
print(r2)

r1.width = 1000
print(r1.width)
print(r1.height)
print(r1)
print(r2)
*/

// Computed Properties
struct Point {
    var x = 0.0, y = 0.0
}
struct Size {
    var width = 0.0, height = 0.0
}
struct Rectangle {
    var origin = Point()
    var size = Size()
    var center: Point {
        get {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
        set(newCenter) {
            origin.x = newCenter.x - (size.width / 2)
            origin.y = newCenter.y - (size.height / 2)
        }
    }
}

/*
struct Rectangle1 {
    var origin = Point()
    var size = Size()
    func getCenter() {
            let centerX = origin.x + (size.width / 2)
            let centerY = origin.y + (size.height / 2)
            return Point(x: centerX, y: centerY)
        }
    func setCenter(newValue: Point) {
            origin.x = newValue.x - (size.width / 2)
            origin.y = newValue.y - (size.height / 2)
        }
    }
}
*/

var pointR = Point(x:0.0, y:0.0)
var sizeR  = Size(width: 6, height: 4)
var rect  = Rectangle(origin: pointR, size: sizeR)
print(rect.origin, rect.size)
print(rect.center)
//rect.getCenter()
//rect.setCenter(newValue)

rect.center = Point(x: 10, y: 10)
//rect.center.set(Point(x: 10, y: 10)) //Genrate

print(rect.center)
//print(rect.center.get())
print(rect.origin)
*/

// Property Observers
class StepCounter {
    let minSteps: Int = 500
    var totalSteps: Int = 0 {
        willSet(newTotalSteps) {
            print("willSet Called: \(newTotalSteps)")
        }
        didSet {
            print("didSet Called: \(totalSteps)")
            if totalSteps < minSteps {
                print("    Need To Walk More...")
                totalSteps = 0
            }
        }
    }
}

var stepcounter = StepCounter()
print(stepcounter.totalSteps)
print(stepcounter.minSteps)

stepcounter.totalSteps = 10
print(stepcounter.totalSteps)

stepcounter.totalSteps = 200
print(stepcounter.totalSteps)

stepcounter.totalSteps = 800
print(stepcounter.totalSteps)


/*
    //setCounter.totalSteps.willSet()
    //stepCounter.totalSteps.set(10)
    //setCounter.totalSteps.didSet()
print(stepcounter.totalSteps)


*/



